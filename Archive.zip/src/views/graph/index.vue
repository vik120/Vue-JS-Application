<template src="./graph.html"></template>
<script src="./graph.js"></script>
<style src="./graph.scss" scoped lang="scss"></style>
