<template src="./imageblock.html"></template>
<script src="./imageblock.js"></script>
<style src="./imageblock.scss" lang="scss"></style>
