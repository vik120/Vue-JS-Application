import sidebar from '../components/sidebar/index'
import wizardHeader from '../components/header/index'
export default {
  name: 'app',
  components: {
    sidebar,
    wizardHeader
  },
  props: [],
  data () {
    return {

    }
  },
  computed: {

  },
  mounted () {

  },
  methods: {

  }
}
